import { Sprite } from '../models/Sprite';
import { Block } from './Block';

//0,=bg //1,=shirt //2,=hair/shoes //3,=skin //4,=button //5,=eyes/mustache //6,=pants
const colorPallette = [
  '#FFFFFF',  //0,=bg
  '#994b0c',  //1,=cap (brown)
  '#ffc8b8',  //2,=eye (white)
  '#000000',  //3,=eyebows (dk gray)
  '#000000',  //4,=unused
  '#000000',  //5,=unused
  '#000000']; //6,=unused

const step1CM = [
  [0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0],
  [0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0],
  [0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0],
  [0,0,0,1,1,1,1,1,1,1,1,1,1,0,0,0],
  [0,0,1,3,3,1,1,1,1,1,1,3,3,1,0,0],
  [0,1,1,1,2,3,1,1,1,1,3,2,1,1,1,0],
  [0,1,1,1,2,3,3,3,3,3,3,2,1,1,1,0],
  [1,1,1,1,2,3,2,1,1,2,3,2,1,1,1,1],
  [1,1,1,1,2,2,2,1,1,2,2,2,1,1,1,1],
  [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
  [0,1,1,1,1,2,2,2,2,2,2,1,1,1,1,0],
  [0,0,0,0,2,2,2,2,2,2,2,2,0,0,0,0],
  [0,0,5,5,2,2,2,2,2,2,2,2,0,0,0,0],
  [0,5,5,5,5,5,2,2,2,2,2,5,5,0,0,0],
  [0,5,5,5,5,5,5,2,2,2,5,5,5,0,0,0],
  [0,0,5,5,5,5,5,2,2,5,5,5,0,0,0,0]];

const step2CM = [
  [0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0],
  [0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0],
  [0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0],
  [0,0,0,1,1,1,1,1,1,1,1,1,1,0,0,0],
  [0,0,1,3,3,1,1,1,1,1,1,3,3,1,0,0],
  [0,1,1,1,2,3,1,1,1,1,3,2,1,1,1,0],
  [0,1,1,1,2,3,3,3,3,3,3,2,1,1,1,0],
  [1,1,1,1,2,3,2,1,1,2,3,2,1,1,1,1],
  [1,1,1,1,2,2,2,1,1,2,2,2,1,1,1,1],
  [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
  [0,1,1,1,1,2,2,2,2,2,2,1,1,1,1,0],
  [0,0,0,0,2,2,2,2,2,2,2,2,0,0,0,0],
  [0,0,0,0,2,2,2,2,2,2,2,2,5,5,0,0],
  [0,0,0,5,5,2,2,2,2,2,5,5,5,5,5,0],
  [0,0,0,5,5,5,2,2,2,5,5,5,5,5,5,0],
  [0,0,0,0,5,5,5,2,2,5,5,5,5,5,0,0]];

const INIT_VEL: any = {x: 200/1000, y: 300};
const INIT_POS: any = {x: 800, y: 300};

export class Enemy extends Block {
  private _moveLeft: boolean;
  private vel: any = INIT_VEL;
  private gra: any = INIT_VEL;

  constructor(options) {
    super({
      sprites: [
        new Sprite({ context: options.context, dataMaps: [ step1CM, step2CM ], pos: { x: INIT_POS.x, y: INIT_POS.y }, colorPallette: colorPallette })] //WALK LEFT
    });
    this._moveLeft = options.moveLeft;
  }

  get moveLeft(): boolean {
    return this._moveLeft;
  }

  set moveLeft(value: boolean) {
    this._moveLeft = value;
  }

  get velocity(): any {
    return this.vel;
  }

  set velocity(value: any){
    this.vel = value;
  }

  get gravity(): any {
    return this.gra;
  }

  set gravity(value: any){
    this.gra = value;
  }
  
  public update(options) {
    if (this.isTerminated){
      // console.log("Hey, dog. This aint for me, neither! - Goomba")
    }
    this.bounds.forEach(sprite => { sprite.update({ pos: {x: options.bg.x + options.char.x, y: options.bg.y + options.char.y} });   });
  };
}